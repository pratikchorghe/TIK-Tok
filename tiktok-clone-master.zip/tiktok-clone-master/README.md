## TikTok Clone 🚀 🚀 🚀

Live Demo 👉 https://tik-tok-clone-eb635.web.app/

![Here is the Image](https://i.imgur.com/MaHnHSh.png)

### How to get Started!

To run the app, clone it to your computer and run `npm start`

- Made by Sonny & Qazi ♥️ 
